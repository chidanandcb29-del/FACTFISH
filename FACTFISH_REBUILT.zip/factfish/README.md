# FactFish — Proof Before Panic

FactFish is an evidence-first public-information verification app. Users submit a claim or message, the backend starts a real TinyFish Web Agent investigation, and the app presents returned source evidence with a deterministic evidence-support score.

> A verification score is not a calibrated probability of truth. `NOT FOUND` is not the same as `CONTRADICTED`. If the agent fails, FactFish reports an investigation failure and does not generate a verdict.

## Architecture

```mermaid
flowchart TD
  U[Browser UI] --> API[FastAPI application]
  API --> S[Anonymous HTTP-only session]
  API --> DB[(SQLite / PostgreSQL)]
  API --> SAFE[Input & URL safety checks]
  SAFE --> TF[TinyFish Agent API /run-sse]
  TF --> WEB[Public web pages]
  TF --> PARSE[Evidence validation]
  PARSE --> SCORE[Deterministic scoring]
  SCORE --> DB
  DB --> UI[Report / history / PDF / JSON]
```

## Stack

- Python 3.11+
- FastAPI + Pydantic
- SQLAlchemy 2
- SQLite by default; PostgreSQL via `DATABASE_URL`
- TinyFish Agent API using its documented streaming REST endpoint
- Vanilla HTML/CSS/JavaScript frontend (served by FastAPI)
- ReportLab for PDF exports

The official TinyFish Python SDK is available as `pip install tinyfish`; this implementation uses TinyFish's documented raw HTTP SSE interface so the backend can proxy the event stream directly to the UI. API reference: https://docs.tinyfish.ai/agent-api/reference and endpoint guide: https://docs.tinyfish.ai/key-concepts/endpoints.

## Quick start (Windows PowerShell)

```powershell
cd factfish
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
uvicorn app.main:app --reload
```

Set `TINYFISH_API_KEY` in `.env`. Create a key at https://agent.tinyfish.ai/api-keys. Never put the key in frontend code or commit `.env`.

Open http://localhost:8000. Without a valid TinyFish key, the interface and local features start, but live investigations fail clearly rather than showing sample or fabricated results.

## Environment

| Variable | Purpose |
|---|---|
| `TINYFISH_API_KEY` | Server-side TinyFish credential |
| `TINYFISH_BASE_URL` | Defaults to `https://agent.tinyfish.ai` |
| `DATABASE_URL` | Defaults to `sqlite:///./factfish.db`; use a PostgreSQL URL in production |
| `APP_SECRET_KEY` | Replace with a long random secret |
| `ADMIN_SECRET` | Optional secret for protected admin metrics endpoint |
| `FRONTEND_URL` | Deployment origin |
| `ENVIRONMENT` | Set `production` to enable Secure session cookies |
| `MAX_UPLOAD_MB` | Upload size cap (default 10 MB) |

## Current implementation status

Implemented in this source package:

- Original FactFish dark interface and responsive layout
- Five verification modes: Forward, Job, Fee, Deadline, Link
- Actual TinyFish `/v1/automation/run-sse` invocation with API-key header
- Live progress event proxying to browser via application SSE
- Structured evidence validation and clickable source links
- Deterministic score breakdown and six verdict states (`CONFIRMED`, `LIKELY GENUINE`, `UNCERTAIN`, `SUSPICIOUS`, `CONTRADICTED`, `NOT FOUND`)
- Rule-based scam-pattern flags
- Anonymous browser-scoped history, report detail, individual/all deletion
- 15-day expiry field and cleanup at startup and history access
- PDF and JSON exports
- Protected admin metrics API (`GET /api/admin/metrics`, header `X-Admin-Secret`)
- PDF text extraction when PyMuPDF is installed; OCR when Pillow, pytesseract and the system Tesseract binary are installed
- Health endpoint and automated core tests

Not enabled / remaining production work (not falsely advertised as working):

- Translation: `/api/translate` returns an explicit `501` until a tested local translation model is installed. Language selector is a display preference only; source-language detection/translation is not currently performed.
- Image OCR dependencies are optional and must be installed separately; visual authenticity/manipulation detection is not implemented.
- Report sharing/revocation is not implemented.
- Admin UI, full operational analytics, migrations/Alembic, distributed task queue, persistent SSE replay after process restart, rate limiting, CSRF protection for cross-site deployments, and scheduled background retention worker need production hardening.
- The app does not claim complete internet-wide coverage. TinyFish's agent explores publicly accessible sources relevant to the task; blocked, private, login-gated or inaccessible sources may be unavailable.

## API

- `POST /api/verify` — start a report (`text`, `mode`, `language`)
- `GET /api/verify/{report_id}/stream` — stream progress events
- `GET /api/verify/{report_id}` — report details
- `GET /api/history` — current browser session's reports
- `DELETE /api/history/{report_id}` — delete one report
- `DELETE /api/history` — clear session history
- `POST /api/upload` — extract text from PDF/image when dependencies exist
- `GET /api/reports/{report_id}/pdf` — PDF export
- `GET /api/reports/{report_id}/json` — JSON export
- `GET /api/health` — health/configuration status
- `GET /api/admin/metrics` — protected metrics endpoint

## Tests

```bash
pytest -q
```

## Docker

```bash
docker compose up --build
```

For production, use HTTPS, a persistent PostgreSQL database, a strong random `APP_SECRET_KEY`, a separate `ADMIN_SECRET`, an appropriate reverse proxy, request limits, and a durable job/event store. Do not run multiple workers with the in-memory event/task registry until that registry is replaced by Redis or another shared broker.

## Safety and limitations

- TinyFish page content is treated as untrusted input. The agent is instructed not to follow webpage instructions, log in, submit forms, register, or pay.
- Submitted URL inputs are checked for malformed, credential-bearing and private-network destinations. This is defence-in-depth, not a substitute for network egress controls in production.
- Reports are associated with a random HTTP-only browser session cookie. Anyone with access to that browser profile may see its history.
- The 15-day deletion is enforced when the app starts and when history is accessed; production deployments should add a scheduled cleanup job.
- Do not submit OTPs, passwords, payment credentials or other secrets.
