from app.scoring import score_evidence
from app.security import scan_patterns, validate_public_url

def test_no_evidence_is_not_found():
    score, verdict, parts = score_evidence([])
    assert verdict == "NOT FOUND"
    assert score == 0

def test_official_contradiction_caps_score():
    evidence=[{"source_type":"official","stance":"contradicts","domain":"example.gov"},{"source_type":"independent","stance":"supports","domain":"news.test"}]
    score, verdict, _ = score_evidence(evidence)
    assert score <= 19
    assert verdict == "CONTRADICTED"

def test_payment_scam_pattern():
    findings=scan_patterns("Pay registration fee to secure guaranteed internship today")
    assert findings

def test_reject_non_http_url():
    try: validate_public_url("javascript:alert(1)")
    except ValueError: return
    assert False

def test_accept_public_url_syntax():
    assert validate_public_url("https://example.com") == "https://example.com"
