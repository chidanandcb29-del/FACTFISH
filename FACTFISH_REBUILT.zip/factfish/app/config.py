from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    tinyfish_api_key: str = ""
    tinyfish_base_url: str = "https://agent.tinyfish.ai"
    database_url: str = "sqlite:///./factfish.db"
    app_secret_key: str = "development-only-change-me"
    admin_secret: str = ""
    frontend_url: str = "http://localhost:8000"
    environment: str = "development"
    max_upload_mb: int = 10
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

settings = Settings()
