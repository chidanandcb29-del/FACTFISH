from collections import defaultdict

WEIGHTS={"source_authority":25,"independent_corroboration":20,"direct_support":20,"detail_consistency":15,"recency_relevance":10,"contradiction_absence":10}

def score_evidence(evidence: list[dict], limitations: list[str] | None = None):
    limitations=limitations or []
    official=[e for e in evidence if e.get("source_type")=="official"]
    independent=[e for e in evidence if e.get("source_type")=="independent"]
    support=[e for e in evidence if e.get("stance")=="supports"]
    contradict=[e for e in evidence if e.get("stance")=="contradicts"]
    # Deduplicate publisher domains to avoid counting copied stories repeatedly.
    domains={e.get("domain") for e in independent if e.get("domain")}
    parts={
      "source_authority": 25 if official else (12 if evidence else 0),
      "independent_corroboration": min(20, len(domains)*7),
      "direct_support": min(20, len(support)*10),
      "detail_consistency": 15 if support and not contradict else (7 if evidence else 0),
      "recency_relevance": 10 if any(e.get("retrieved_at") for e in evidence) else 0,
      "contradiction_absence": 10 if not contradict else 0,
    }
    if not evidence:
        parts={k:0 for k in WEIGHTS}
    score=sum(parts.values())
    if any(e.get("source_type")=="official" and e.get("stance")=="contradicts" for e in evidence): score=min(score,19)
    if not evidence: score=0
    score=max(0,min(100,int(score)))
    if not evidence: verdict="NOT FOUND"
    elif any(e.get("source_type")=="official" and e.get("stance")=="contradicts" for e in evidence): verdict="CONTRADICTED"
    elif contradict and support: verdict="UNCERTAIN"
    elif score>=90: verdict="CONFIRMED"
    elif score>=70: verdict="LIKELY GENUINE"
    elif score>=40: verdict="UNCERTAIN"
    else: verdict="SUSPICIOUS"
    return score,verdict,{k:{"earned":v,"possible":WEIGHTS[k]} for k,v in parts.items()}
