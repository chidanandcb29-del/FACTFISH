import hashlib, hmac, ipaddress, re, socket
from urllib.parse import urlparse
from fastapi import Request, HTTPException
from .config import settings

SUSPICIOUS_PATTERNS = [
 (r"\b(pay|payment|transfer|upi)\b.{0,50}\b(internship|job|offer|registration|security)\b", "Payment requested to secure an opportunity", "high"),
 (r"\b(otp|one.time.password|password|pin)\b", "Sensitive authentication information requested", "high"),
 (r"\b(guaranteed|100% guaranteed)\b.{0,40}\b(job|placement|internship)\b", "Guaranteed employment claim", "medium"),
 (r"\b(urgent|immediately|within \d+ minutes|today only)\b", "Urgency or pressure language", "medium"),
 (r"\b(personal upi|send to my|individual account)\b", "Payment may be directed to a personal account", "high"),
]

def scan_patterns(text):
    out=[]
    for pattern, label, severity in SUSPICIOUS_PATTERNS:
        if re.search(pattern, text, re.I|re.S): out.append({"label":label,"severity":severity,"explanation":"This pattern is a warning signal, not proof of fraud."})
    return out

def validate_public_url(value: str):
    p=urlparse(value)
    if p.scheme not in ("http","https") or not p.hostname: raise ValueError("Enter a valid HTTP or HTTPS URL")
    if p.username or p.password: raise ValueError("URLs containing credentials are not accepted")
    host=p.hostname.lower().rstrip(".")
    if host in ("localhost",) or host.endswith((".local", ".internal")): raise ValueError("Local network addresses are not allowed")
    try:
        infos=socket.getaddrinfo(host, p.port or (443 if p.scheme=="https" else 80), type=socket.SOCK_STREAM)
        for info in infos:
            ip=ipaddress.ip_address(info[4][0])
            if not ip.is_global: raise ValueError("Private or reserved network addresses are not allowed")
    except socket.gaierror:
        pass
    return value

def admin_ok(request: Request):
    supplied=request.headers.get("x-admin-secret", "")
    return bool(settings.admin_secret and hmac.compare_digest(supplied, settings.admin_secret))

def require_admin(request: Request):
    if not admin_ok(request): raise HTTPException(status_code=401, detail="Admin authentication required")
