import asyncio, io, json, re, time, uuid, secrets
from datetime import datetime, timezone, timedelta
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, StreamingResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from xml.sax.saxutils import escape
from .config import settings
from .db import Base, engine, get_db, SessionLocal, Report, SystemEvent, cleanup_expired
from .security import scan_patterns, validate_public_url, require_admin
from .scoring import score_evidence
from .tinyfish import investigate, TinyFishError

Base.metadata.create_all(bind=engine)
app=FastAPI(title="FactFish API",version="1.0.0",description="Evidence-first public information verification")
app.mount("/static",StaticFiles(directory=Path(__file__).parent/"static"),name="static")
EVENTS: dict[str,list[dict]]={}
TASKS: dict[str,asyncio.Task]={}

class VerifyInput(BaseModel):
    text: str = Field(min_length=4,max_length=8000)
    mode: str = Field(default="forward",pattern="^(forward|job|fee|deadline|link)$")
    language: str = Field(default="auto",max_length=20)

@app.middleware("http")
async def session_cookie(request: Request, call_next):
    sid=request.cookies.get("ff_session")
    fresh=not sid or not re.fullmatch(r"[a-f0-9]{64}",sid)
    if fresh: sid=secrets.token_hex(32)
    request.state.session_id=sid
    response=await call_next(request)
    if fresh: response.set_cookie("ff_session",sid,httponly=True,secure=settings.environment=="production",samesite="lax",max_age=60*60*24*30)
    return response

@app.get("/",response_class=HTMLResponse)
def home(): return (Path(__file__).parent/"static"/"index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health(db: Session=Depends(get_db)):
    try: db.execute(__import__('sqlalchemy').text("SELECT 1")); database="ok"
    except Exception: database="error"
    return {"status":"ok" if database=="ok" else "degraded","database":database,"tinyfish_configured":bool(settings.tinyfish_api_key),"timestamp":datetime.now(timezone.utc).isoformat()}

async def process_report(report_id: str, query: str, mode: str, session_id: str):
    started=time.monotonic()
    def emit_sync(event): EVENTS.setdefault(report_id,[]).append(event)
    async def on_event(event):
        emit_sync({"kind":"agent_event","event":event,"at":datetime.now(timezone.utc).isoformat()})
        if event.get("type")=="STARTED":
            with SessionLocal() as db:
                r=db.get(Report,report_id)
                if r: r.tinyfish_run_id=event.get("run_id"); r.status="running"; db.commit()
    try:
        EVENTS.setdefault(report_id,[]).append({"kind":"stage","stage":"Analysing claim","message":"Extracting the key facts and entities."})
        findings=await investigate(query,mode,on_event)
        evidence=[]
        for item in findings.get("evidence",[]) if isinstance(findings.get("evidence"),list) else []:
            if not isinstance(item,dict): continue
            url=item.get("url","")
            if not isinstance(url,str) or not url.startswith(("http://","https://")): continue
            try: validate_public_url(url)
            except ValueError: continue
            domain=re.sub(r"^www\.","",__import__('urllib.parse').parse.urlparse(url).hostname or "")
            evidence.append({**item,"domain":domain,"retrieved_at":datetime.now(timezone.utc).isoformat()})
        score,verdict,breakdown=score_evidence(evidence,findings.get("limitations",[]))
        findings["evidence"]=evidence
        findings["score_explanation"]="Evidence-support score, not a calibrated probability of truth. Source quality and direct contradictions take priority over source count."
        findings["red_flags"]=(findings.get("red_flags") or []) + scan_patterns(query)
        findings["limitations"]=findings.get("limitations") or []
        with SessionLocal() as db:
            r=db.get(Report,report_id)
            if r:
                r.status="completed"; r.verdict=verdict; r.score=score; r.score_breakdown=breakdown; r.report_data=findings; r.tinyfish_run_id=findings.get("tinyfish_run_id"); db.commit()
            db.add(SystemEvent(kind="success",detail=mode,duration_ms=int((time.monotonic()-started)*1000))); db.commit()
        emit_sync({"kind":"complete","report_id":report_id,"verdict":verdict,"score":score,"status":"completed"})
    except Exception as exc:
        message=str(exc) if isinstance(exc,TinyFishError) else "The investigation could not be completed. Please try again."
        with SessionLocal() as db:
            r=db.get(Report,report_id)
            if r: r.status="failed"; r.report_data={"error":message,"limitations":["No verdict was generated because the investigation failed."]}; db.commit()
            db.add(SystemEvent(kind="failure",detail=type(exc).__name__,duration_ms=int((time.monotonic()-started)*1000))); db.commit()
        emit_sync({"kind":"error","message":message,"status":"failed"})

@app.post("/api/verify")
async def verify(payload: VerifyInput, request: Request, db: Session=Depends(get_db)):
    query=payload.text.strip()
    if not query: raise HTTPException(422,"Enter a claim or message")
    # URL checks are applied to URL-shaped inputs before any remote browser request.
    urls=re.findall(r"https?://[^\s<>\"']+",query)
    for url in urls:
        try: validate_public_url(url.rstrip(".,);"))
        except ValueError as exc: raise HTTPException(422,str(exc))
    rid=str(uuid.uuid4())
    record=Report(id=rid,session_id=request.state.session_id,original_text=query,mode=payload.mode,language=payload.language,status="queued",expires_at=datetime.now(timezone.utc)+timedelta(days=15))
    db.add(record); db.commit()
    EVENTS[rid]=[{"kind":"stage","stage":"Investigation queued","message":"Preparing a live TinyFish investigation."}]
    TASKS[rid]=asyncio.create_task(process_report(rid,query,payload.mode,request.state.session_id))
    return {"report_id":rid,"status":"queued","stream_url":f"/api/verify/{rid}/stream"}

@app.get("/api/verify/{report_id}/stream")
async def stream_report(report_id: str, request: Request, db: Session=Depends(get_db)):
    cleanup_expired(db)
    r=db.get(Report,report_id)
    if not r or r.session_id!=request.state.session_id: raise HTTPException(404,"Report not found")
    async def gen():
        idx=0
        while True:
            if await request.is_disconnected(): break
            events=EVENTS.get(report_id,[])
            while idx<len(events):
                yield f"data: {json.dumps(events[idx],ensure_ascii=False)}\n\n"; idx+=1
            with SessionLocal() as check:
                current=check.get(Report,report_id)
                if current and current.status in ("completed","failed") and idx>=len(EVENTS.get(report_id,[])): break
            await asyncio.sleep(.5)
        yield "event: end\ndata: {}\n\n"
    return StreamingResponse(gen(),media_type="text/event-stream",headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.get("/api/verify/{report_id}")
def get_report(report_id: str, request: Request, db: Session=Depends(get_db)):
    cleanup_expired(db)
    r=db.get(Report,report_id)
    if not r or r.session_id!=request.state.session_id: raise HTTPException(404,"Report not found")
    return serialize(r)

def serialize(r):
    return {"report_id":r.id,"original_text":r.original_text,"translated_text":r.translated_text,"mode":r.mode,"language":r.language,"status":r.status,"verdict":r.verdict,"score":r.score,"score_breakdown":r.score_breakdown,"report":r.report_data,"created_at":r.created_at.isoformat() if r.created_at else None,"expires_at":r.expires_at.isoformat() if r.expires_at else None}

@app.get("/api/history")
def history(request: Request, db: Session=Depends(get_db)):
    cleanup_expired(db)
    rows=db.query(Report).filter(Report.session_id==request.state.session_id).order_by(Report.created_at.desc()).limit(100).all()
    return {"items":[{"report_id":r.id,"created_at":r.created_at.isoformat() if r.created_at else None,"mode":r.mode,"status":r.status,"verdict":r.verdict,"score":r.score,"preview":r.original_text[:100]} for r in rows]}

@app.delete("/api/history/{report_id}")
def delete_report(report_id: str, request: Request, db: Session=Depends(get_db)):
    r=db.get(Report,report_id)
    if not r or r.session_id!=request.state.session_id: raise HTTPException(404,"Report not found")
    db.delete(r); db.commit(); EVENTS.pop(report_id,None); return {"deleted":True}

@app.delete("/api/history")
def clear_history(request: Request, db: Session=Depends(get_db)):
    db.query(Report).filter(Report.session_id==request.state.session_id).delete(synchronize_session=False); db.commit(); return {"cleared":True}

@app.post("/api/translate")
def translate_unavailable():
    raise HTTPException(501,"Translation is not enabled in this build. FactFish preserves the original message; connect a locally installed translation model before enabling translations.")

@app.post("/api/upload")
async def upload(file: UploadFile=File(...)):
    allowed={"application/pdf","image/png","image/jpeg","image/webp"}
    if file.content_type not in allowed: raise HTTPException(415,"Only PDF, PNG, JPEG and WebP files are supported")
    data=await file.read(settings.max_upload_mb*1024*1024+1)
    if len(data)>settings.max_upload_mb*1024*1024: raise HTTPException(413,"File exceeds configured size limit")
    extracted=""
    if file.content_type=="application/pdf":
        try:
            import fitz
            doc=fitz.open(stream=data,filetype="pdf"); extracted="\n".join(p.get_text() for p in doc)[:8000]
        except ImportError: raise HTTPException(501,"PDF extraction requires PyMuPDF. Install pymupdf and restart.")
        except Exception: raise HTTPException(422,"Could not read this PDF")
    else:
        try:
            import pytesseract
            from PIL import Image
            extracted=pytesseract.image_to_string(Image.open(io.BytesIO(data)))[:8000]
        except ImportError: raise HTTPException(501,"Image OCR requires Pillow and pytesseract plus the Tesseract binary.")
        except Exception: raise HTTPException(422,"Could not extract readable text from this image")
    return {"filename":file.filename,"extracted_text":extracted,"needs_review":True,"visual_authenticity_checked":False}

@app.get("/api/reports/{report_id}/json")
def export_json(report_id: str, request: Request, db: Session=Depends(get_db)):
    cleanup_expired(db)
    r=db.get(Report,report_id)
    if not r or r.session_id!=request.state.session_id: raise HTTPException(404,"Report not found")
    return JSONResponse(serialize(r),headers={"Content-Disposition":f'attachment; filename="factfish-{report_id}.json"'})

@app.get("/api/reports/{report_id}/pdf")
def export_pdf(report_id: str, request: Request, db: Session=Depends(get_db)):
    cleanup_expired(db)
    r=db.get(Report,report_id)
    if not r or r.session_id!=request.state.session_id: raise HTTPException(404,"Report not found")
    buf=io.BytesIO(); doc=SimpleDocTemplate(buf,pagesize=A4); styles=getSampleStyleSheet(); story=[Paragraph("FACTFISH · VERIFICATION REPORT",styles["Title"]),Paragraph("Proof Before Panic",styles["Italic"]),Spacer(1,14)]
    for label,value in [("Verdict",r.verdict),("Evidence-support score",f"{r.score}/100"),("Report ID",r.id),("Created",str(r.created_at)),("Original claim",r.original_text)]: story += [Paragraph(f"<b>{label}</b>",styles["Heading3"]),Paragraph(escape(str(value)),styles["BodyText"]),Spacer(1,6)]
    data=r.report_data or {}
    story += [Paragraph("Findings",styles["Heading2"]),Paragraph(escape(str(data.get("summary","No findings available."))),styles["BodyText"]),Spacer(1,8)]
    for e in data.get("evidence",[]): story += [Paragraph(str(e.get("title","Source")),styles["Heading3"]),Paragraph(escape(str(e.get("url",""))+" — "+str(e.get("stance",""))+" — "+str(e.get("excerpt",""))),styles["BodyText"]),Spacer(1,6)]
    story += [Spacer(1,10),Paragraph("This score is not a calibrated probability. Verify important decisions with the original organisation.",styles["Italic"])]
    doc.build(story); return Response(buf.getvalue(),media_type="application/pdf",headers={"Content-Disposition":f'attachment; filename="factfish-{report_id}.pdf"'})

@app.get("/api/admin/metrics")
def admin_metrics(request: Request, db: Session=Depends(get_db)):
    require_admin(request)
    return {"reports":db.query(Report).count(),"completed":db.query(Report).filter(Report.status=="completed").count(),"failed":db.query(Report).filter(Report.status=="failed").count(),"tinyfish_configured":bool(settings.tinyfish_api_key),"recent_events":[{"kind":e.kind,"detail":e.detail,"duration_ms":e.duration_ms,"created_at":e.created_at.isoformat()} for e in db.query(SystemEvent).order_by(SystemEvent.created_at.desc()).limit(20)]}

@app.on_event("startup")
async def startup_cleanup():
    with SessionLocal() as db: cleanup_expired(db)
