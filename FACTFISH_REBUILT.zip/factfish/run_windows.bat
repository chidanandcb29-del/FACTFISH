@echo off
if not exist .venv py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo Configure TINYFISH_API_KEY in .env, then press any key.
pause
uvicorn app.main:app --reload
